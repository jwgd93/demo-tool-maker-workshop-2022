import CompuCellSetup
from PySteppables import *
from PySteppablesExamples import MitosisSteppableBase
from PlayerPython import *
from math import *
import CompuCell
import sys
import random
from random import random
from random import randint


#import bionetAPI
from copy import deepcopy
# add random probabilities for one cell type to become another.


class BasicCASteppable(SteppableBasePy):    

    def __init__(self,_simulator,_frequency=1):
        SteppableBasePy.__init__(self,_simulator,_frequency)
        self.simulator = _simulator
        self.inventory = self.simulator.getPotts().getCellInventory()
        self.cellList = CellList(self.inventory)
        self.fileDict={'Totalcell':None,'Fastgrowingcells':None,'Slowgrowingcells':None,'Tcells':None,'RestingMacs':None,'ActiveMacs':None,'InfectedMacs':None,\
        'ChronInfectedMacs':None\
        }

    
    def start(self):
        for fileLabel in self.fileDict.keys():
            fileObj, fullFileName=CompuCellSetup.openFileInSimulationOutputDirectory(_filePath=fileLabel+'.txt',_mode="w")            
            self.fileDict[fileLabel]=fileObj
        
        # iterating over all cells in simulation        
        for cell in self.cellList:
            # you can access/manipulate cell properties here
            cell.targetVolume=25
            cell.lambdaVolume=2.0
       
    def step(self,mcs): 

        #type here the code that will run every _frequency MCS
        Total_no=0
        Fastgrowing_no=0
        Slowgrowing_no=0
        Tcell_no=0
        RestingMac_no=0
        InfectedMac_no=0
        ActiveMac_no=0
        ChronInfectedMac_no=0
        
        
        for cell in self.cellList:
            if cell.type==1:
                if cell.targetVolume<50:
                    
                    cell.targetVolume+=0.5 
                  
        for cell in self.cellList:
            if cell.type==2 :
                if cell.targetVolume<50:
                    
                    cell.targetVolume+=0.15  
            
            if cell.type==3:
                cell.targetVolume=cell.targetVolume
           
            
            if cell.type==1:
                Fastgrowing_no=Fastgrowing_no+1
                Total_no=Total_no+1
            if cell.type==2:
                Slowgrowing_no=Slowgrowing_no+1 
                Total_no=Total_no+1
            if cell.type==4: 
                Tcell_no=Tcell_no+1   
            if cell.type==5:
                RestingMac_no=RestingMac_no+1           
            if cell.type==6:
                ActiveMac_no=ActiveMac_no+1       
            if cell.type==7:
                InfectedMac_no=InfectedMac_no+1
            if cell.type==8:
                ChronInfectedMac_no=ChronInfectedMac_no+1       
                       
                        
        self.fileDict['Totalcell'].write('%s \n'%(Total_no))
        self.fileDict['Fastgrowingcells'].write('%s \n'%(Fastgrowing_no))
        self.fileDict['Slowgrowingcells'].write('%s \n'%(Slowgrowing_no))
        self.fileDict['Tcells'].write('%s \n'%(Tcell_no))
        self.fileDict['RestingMacs'].write('%s \n'%(RestingMac_no))
        self.fileDict['ActiveMacs'].write('%s \n'%(ActiveMac_no))
        self.fileDict['InfectedMacs'].write('%s \n'%(InfectedMac_no))
        self.fileDict['ChronInfectedMacs'].write('%s \n'%(ChronInfectedMac_no))

       # self.fileDict['cell'].write('MCS=%s,\tTotal=%s,\tFastgrowing=%s,\tSlowgrowing=%s,\t Tcells=%s,\tRestingMacs=%s, \tActiveMacs=%s, \t InfectedMacs=%s,\t ChronInfectedMacs=%s\n'%(mcs,Total_no,Fastgrowing_no,Slowgrowing_no,Tcell_no,RestingMac_no,ActiveMac_no,InfectedMac_no,ChronInfectedMac_no))    

    
    def finish(self):
        # Finish Function gets called after the last MCS
       for fileLabel,fileObj in self.fileDict.items():
            fileObj.close()
            

class BionetSteppable(SteppableBasePy):
    def __init__(self,_simulator,_frequency=1):
        SteppableBasePy.__init__(self,_simulator,_frequency)
        # bionetAPI.initializeBionetworkManager(self.simulator)
        self.tV=25
        self.myfile=''
        
    def start(self):
        #Loading model

        IntegrationStep = 0.1
       
        #Initial conditions
        
    

        ###################################

        
        self.myfile,fullFileName=CompuCellSetup.openFileInSimulationOutputDirectory(_filePath='celldeath_data.txt',_mode="w")  
        
        

    
    def step(self,mcs):        
        T1chemo1_kill=0
        T1chemo1_intra_kill=0

        cellsToBeDeleted=[] #empty lits ***************
        field=CompuCell.getConcentrationField(self.simulator,"Oxygen") #*******
        field2=CompuCell.getConcentrationField(self.simulator,"Chemo1") #*******
        field3=CompuCell.getConcentrationField(self.simulator,"Chemokine") #*******
 
        #finding min/max of oxygen concentration
        pt=CompuCell.Point3D()
        minField_o2=1e12 #some large number
        maxField_o2=0.0 # we assume concentration cannot be negative
        for pt.x in range(self.dim.x):
            for pt.y in range(self.dim.y):
                for pt.z in range(self.dim.z):
                    conc=field.get(pt)
                    if conc>maxField_o2:
                        maxField_o2=conc
                    if conc<minField_o2:
                        minField_o2=conc
                        
        #finding min/max of chemo1 concentration
        pt=CompuCell.Point3D()
        minField_chemo1=1e12 #some large number
        maxField_chemo1=0.0 # we assume concentration cannot be negative
        for pt.x in range(self.dim.x):
            for pt.y in range(self.dim.y):
                for pt.z in range(self.dim.z):
                    conc1=field2.get(pt)
                    if conc1>maxField_chemo1:
                        maxField_chemo1=conc1
                    if conc1<minField_chemo1:
                        minField_chemo1=conc1
                        
                        
                        
        #finding min/max of chemokine concentration
        pt=CompuCell.Point3D()
        minField_chemokine=1e12 #some large number
        maxField_chemokine=0.0 # we assume concentration cannot be negative
        for pt.x in range(self.dim.x):
            for pt.y in range(self.dim.y):
                for pt.z in range(self.dim.z):
                    conc2=field3.get(pt)
                    if conc2>maxField_chemokine:
                        maxField_chemokine=conc2
                    if conc2<minField_chemokine:
                        minField_chemokine=conc2
                        
    
        for cell in self.cellList:
            # oxygen driven switching of bacteria
            
            if cell.type==1:
                #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
                # finding the maximum value of oxygen and chemos at each cell
                pixelList=CellPixelList(self.pixelTrackerPlugin,cell)
                minFieldCell=1e12 #some large number
                maxFieldCell=0.0 # we assume concentration cannot be negative
               
                
                for pixelData in pixelList:
                    comPt=pixelData.pixel
                    concentration=field.get(comPt)
                    
                    #oxygen
                    if concentration>maxFieldCell:
                        maxFieldCell=concentration
                    if concentration<minFieldCell:
                        minFieldCell=concentration
                    
                if mcs>20 and (maxFieldCell/(maxField_o2))*100<6:
                    cell.type=2
                    
            if cell.type==2:
                #$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
                # finding the maximum value of oxygen and chemos at each cell
                pixelList=CellPixelList(self.pixelTrackerPlugin,cell)
                minFieldCell=1e12 #some large number
                maxFieldCell=0.0 # we assume concentration cannot be negative
               
                
                for pixelData in pixelList:
                    comPt=pixelData.pixel
                    concentration=field.get(comPt)
                    
                    #oxygen
                    if concentration>maxFieldCell:
                        maxFieldCell=concentration
                    if concentration<minFieldCell:
                        minFieldCell=concentration
                    
                if mcs>20 and (maxFieldCell/(maxField_o2))*100>65:
                    cell.type=1
      
        
        for cell in self.cellList:
           
            pixelList=CellPixelList(self.pixelTrackerPlugin,cell)
            minChemo1Cell=1e12 #some large number
            maxChemo1Cell=0.0 # we assume concentration cannot be negative

            for pixelData in pixelList:
                comPt=pixelData.pixel
                concentration1=field2.get(comPt)
                    
                #Chemo1
                if concentration1>maxChemo1Cell:
                   maxChemo1Cell=concentration1
                if concentration1<minChemo1Cell:
                   minChemo1Cell=concentration1 
          
            pixelList=CellPixelList(self.pixelTrackerPlugin,cell)
            minChemokineCell=1e12 #some large number
            maxChemokineCell=0.0 # we assume concentration cannot be negative

            for pixelData in pixelList:
                comPt=pixelData.pixel
                concentration2=field3.get(comPt)
                    
                #Chemokine
                if concentration2>maxChemokineCell:
                   maxChemokineCell=concentration2
                if concentration2<minChemokineCell:
                   minChemokineCell=concentration2
          
          
            
            
            if maxField_chemo1!=0:
                if cell.type==1: 
                    if (maxChemo1Cell/(maxField_chemo1))*100>100.000: #0.00025
                        print "\n\n\n\n DELETE Fast growing cell \n\n\n\n"
                        T1chemo1_kill=T1chemo1_kill+1
                        cellsToBeDeleted.append(cell) 
                if cell.type==2: 
                    if (maxChemo1Cell/(maxField_chemo1))*100>100.00025:
                        T1chemo1_kill=T1chemo1_kill+1
                        print "\n\n\n\n DELETE Slowing growing cell \n\n\n\n"
                  
                        cellsToBeDeleted.append(cell)
                if cell.type==7 or cell.type==8: 
                    if (maxChemo1Cell/(maxField_chemo1))*100>0.00025:
                        T1chemo1_intra_kill=T1chemo1_intra_kill+1
                        print "\n\n\n\n DELETE Intracellular cells \n\n\n\n"
                        
                        cellsToBeDeleted.append(cell) 
                
#                        
             
        for cell in cellsToBeDeleted:
            
            self.deleteCell(cell)  
        
     #   self.myfile.write('MCS=%s,\t T1Chemo1kill=%s,\t T1Chemointrakill=%s \n'%(mcs,T1chemo1_kill,T1chemo_intra_kill))    
        #Iterating the ODEs
        
    def finish(self):

        self.myfile.close()
    



class Mitosis(MitosisSteppableBase):
    def __init__(self, _simulator, _frequency=1):
        MitosisSteppableBase.__init__(self, _simulator, _frequency)
    def step(self, mcs): 
        cells_to_divide = []
        for cell in self.cellList:
            if cell.type==1 or cell.type==2:
                if cell.volume > 50: 
                    cells_to_divide.append(cell)
        for cell in cells_to_divide:
            # to change mitosis mode uncomment proper line below 
            self.divideCellRandomOrientation(cell)
            # these are valid option
            # self.divideCellOrientationVectorBased(cell,1,0,0)
            # self.divideCellAlongMajorAxis(cell)
            # self.divideCellAlongMinorAxis(cell)
    def updateAttributes(self):
        self.parentCell.targetVolume = 25.0 # reducing parent target volume 
        self.cloneParent2Child()
   
      


class ConcentrationFieldMonitor(SteppableBasePy):
    def __init__(self,_simulator,_frequency=1):
        SteppableBasePy.__init__(self,_simulator,_frequency)
        
        self.scalarField1=CompuCellSetup.createScalarFieldPy(self.dim,"RelativeOxygen")

    def start(self):
        print "ConcentrationFieldMonitor: This function is called once before simulation"
        
    def step(self,mcs):
        
        field=CompuCell.getConcentrationField(self.simulator,"Oxygen")
 
       #finding min/max
        pt=CompuCell.Point3D()
        minField=1e12 #some large number
        maxField=0.0 # we assume concentration cannot be negative
        
        for x,y,z in self.everyPixel():
            conc=field[x,y,z]
            if conc>maxField:
                maxField=conc
            if conc<minField:
                minField=conc
                        
        print 'minField=',minField
        print 'maxField=',maxField
        
        

        self.scalarField1[:, :, :]=0.0
        
        for x,y,z in self.everyPixel():
            
            conc=field[x,y,z]
            self.scalarField1[x,y,z]=conc/(maxField)*100
            
                    
            
    def finish(self):
        # this function may be called at the end of simulation - used very infrequently though
        return
    

 

from XMLUtils import dictionaryToMapStrStr as d2mss
from XMLUtils import CC3DXMLListPy 

class DiffusionSteering(SteppableBasePy):
    def __init__(self,_simulator,_frequency=1):
        SteppableBasePy.__init__(self,_simulator,_frequency)
        
    def start(self):
        print "DiffusionSteering: This function is called once before simulation"
        
    def step(self,mcs):
                     
        fiexDiffXMLData=self.simulator.getCC3DModuleData("Steppable","FlexibleDiffusionSolverFE")
        diffusionFieldsElementVec=CC3DXMLListPy(fiexDiffXMLData.getElements("DiffusionField"))
        for diffusionFieldElement in diffusionFieldsElementVec:
            if diffusionFieldElement.getFirstElement("DiffusionData").getFirstElement("FieldName").getText()=="Chemo1":
                    
                secretionElement1=diffusionFieldElement.getFirstElement("SecretionData").getFirstElement("Secretion",d2mss({"Type":"Vessel"}))
                secretionConst1=float(secretionElement1.getText())
                if mcs>10:
                    secretionConst1=50
                else:
                    secretionConst1=0
                print "\n\n%%%%% secretionConst1=\n\n",secretionConst1
                #update value of the <Secretion Type="Bacterium">
                secretionElement1.updateElementValue(str(secretionConst1))
        self.simulator.updateCC3DModule(fiexDiffXMLData)
            
            
            
    def finish(self):
        # this function may be called at the end of simulation - used very infrequently though
        return




import sys
from os import environ
from os import getcwd
import string
import random

sys.path.append(environ["PYTHON_MODULE_PATH"])


import CompuCellSetup


sim,simthread = CompuCellSetup.getCoreSimulationObjects()
            
# add extra attributes here

pyAttributeAdder,dictAdder=CompuCellSetup.attachDictionaryToCells(sim)

            
CompuCellSetup.initializeSimulationObjects(sim,simthread)
# Definitions of additional Python-managed fields go here


#Create extra player fields 

#Add Python steppables here
steppableRegistry=CompuCellSetup.getSteppableRegistry()
        
from BasicCASteppables import BasicCASteppable
steppableInstance=BasicCASteppable(sim,_frequency=1)
steppableRegistry.registerSteppable(steppableInstance)
        


from BasicCASteppables import BionetSteppable
instanceOfBionetSteppable=BionetSteppable(_simulator=sim,_frequency=1)
steppableRegistry.registerSteppable(instanceOfBionetSteppable)


from BasicCASteppables import Mitosis
instanceOfMitosis=Mitosis(_simulator=sim,_frequency=1)
steppableRegistry.registerSteppable(instanceOfMitosis)

from BasicCASteppables import ConcentrationFieldMonitor
instanceOfConcentrationFieldMonitor=ConcentrationFieldMonitor(_simulator=sim,_frequency=1)
steppableRegistry.registerSteppable(instanceOfConcentrationFieldMonitor)


from BasicCASteppables import DiffusionSteering
instanceOfDiffusionSteering=DiffusionSteering(_simulator=sim,_frequency=1)
steppableRegistry.registerSteppable(instanceOfDiffusionSteering)



CompuCellSetup.mainLoop(sim,simthread,steppableRegistry)
        
